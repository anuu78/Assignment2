package com.example.vuapp.data.model

data class DashboardResponse(
    val entities: List<Map<String, Any?>>,
    val entityTotal: Int
)
