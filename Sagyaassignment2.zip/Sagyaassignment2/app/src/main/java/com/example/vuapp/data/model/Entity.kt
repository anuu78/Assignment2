package com.example.vuapp.data.model

data class Entity(
    val data: Map<String, Any?> = emptyMap()
)
